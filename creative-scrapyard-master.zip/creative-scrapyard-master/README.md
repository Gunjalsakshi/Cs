# creative-scrapyard
It is an application that was built using python and Django back- end. 
This is web application which provide facility to user that they can sell and buy used item from this site.
